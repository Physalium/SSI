import csv
import random
import math


def normalize(x):
    mininum = min(x)
    maximum = max(x)
    range = maximum - mininum
    return [round(((a - mininum) / range), 4) for a in x]
    # funkcja normaliujaca min-max


path = "zad1/processed.hungarian.data"
data = []

with open(path, "r") as file_o:
    line = file_o.readline()
    while line:
        tab = [float("nan") if x == "?" else x for x in (line.rstrip().split(","))]
        data.append(tab)
        line = file_o.readline()
        # zmieniamy pytajniki na -2000


matrix = []
for i in range(len(data[0])):
    curry_column = []
    for j in range(len(data)):
        curry_column.append(float(data[j][i]))
    curry_column = normalize(curry_column)
    matrix.append(curry_column)
# pobieramy poszczególne kolumny i wrzucamy je do funkcji normalizujacej'

matrix.pop(-2)
matrix.pop(-2)
matrix.pop(-2)
# usuwamy atrybuty z brakujacymi wartosciami


t_matrix = list(zip(*matrix))

# usuniecie nan
for i, row in enumerate(t_matrix):
    if "nan" in str(row):
        t_matrix.pop(i)


train_data = open("zad1/train_data.data", "w")
test_data = open("zad1/test_data.data", "w")

random.shuffle(t_matrix)

train_size = round(0.95 * len(t_matrix))
for i in range(int(len(t_matrix))):
    if i < int(train_size):
        train_data.write(str(t_matrix[i])[1:-1] + "\n")
    else:
        test_data.write(str(t_matrix[i])[1:-1] + "\n")
# dzielimy zbiór wg stosunku 80/20 i zapisujemy do oddzielnych plików
